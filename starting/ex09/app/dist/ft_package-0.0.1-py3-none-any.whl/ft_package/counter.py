
def count_in_list(x: list, search: str) -> int:
    """
    count_in_list(x: list, s: str)\n
    print number of times s  Occurs in x\n
    return None
    """
    return x.count(search)
