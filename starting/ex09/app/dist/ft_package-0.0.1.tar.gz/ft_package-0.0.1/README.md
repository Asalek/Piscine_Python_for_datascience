# List Occurs Counter
A package used to play with strings.

## How To Use
_After installing the package use the following import:_<br>

**from ft_package import count_in_list

_then use the function notmaly : def count_in_list(x: list, search: str) -> int:

## How this package got created with
```
python setup.py sdist bdist_wheel
**This will create a .whl and .tar files in a new dist/ directory. This is the Wheel distribution of your package.



```