#An empty __init__.py file makes all functions from the above modules available when this package is imported
from .counter import count_in_list  
